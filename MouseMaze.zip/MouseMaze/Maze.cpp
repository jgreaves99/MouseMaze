#include "Maze.h"

Maze::Maze()
{
    reset();
}

Maze::Maze(Character *character1, Character *character2) {
    mouse = character1;
    cat = character2;
    reset();
}

void Maze::reset()
{
    char newMaze[HEIGHT][WIDTH] =  {{'#',' ','#','#','#','#',' ','#','#','#'},
                                    {'#',' ','#','#','#','#',' ','#','#','#'},
                                    {'#',' ',' ',' ','#',' ',' ',' ','#','#'},
                                    {'#','#',' ','#','#',' ','#',' ','#','#'},
                                    {'#',' ',' ',' ',' ',' ','#',' ','#','#'},
                                    {'#',' ','#','#',' ','#','#',' ','#','#'},
                                    {'#',' ',' ',' ',' ','#','#',' ',' ','#'},
                                    {'#','#',' ','#',' ',' ',' ',' ','#','#'},
                                    {'#',' ',' ','#','#','#',' ','#','#','#'},
                                    {'#','#','#','#','#','#','F','#','#','#'}};
    for (int i = 0; i <= HEIGHT - 1; i++)
    {
        for (int j = 0; j <= WIDTH - 1; j++)
        {
            maze[i][j] = newMaze[i][j];
        }
    }

}

void Maze::setNode(Character *character, int x, int y)
{
    if((x < WIDTH && y < HEIGHT) && (x >= 0 && y >= 0))
    {
        maze[x][y] = character->getRep();
        clearNode(character->getX(), character->getY());
        character->setLocation(x, y);
    }
}

char Maze::getNode(int w, int h)
{
    if((w < WIDTH && h < HEIGHT) && (w >= 0 && h >= 0))
        return maze[w][h];
    else
        return '/0';
}

void Maze::clearNode(int x, int y)
{
    maze[x][y] = ' ';
}

bool Maze::winnerFound()
{
    if(mouse->foundTarget())
    {
        std::cout << "Mouse Found the Cheese!" << std::endl;
        return true;
    }
    else if(cat->foundTarget())
    {
        std::cout << "Cat Ate the Mouse!" << std::endl;
        return true;
    }
    else
    {
        return false;
    }
}

void Maze::update()
{
    mouse->move();
    cat->move();
    printMaze();
}

void Maze::addCharacters(Character *character1, Character *character2)
{
    mouse = character1;
    cat = character2;

    setNode(mouse, mouse->getX(), mouse->getY());
    setNode(cat, cat->getX(), cat->getY());
    printMaze();
}

void Maze::printMaze()
{
    for (int i = 0; i <= HEIGHT - 1; i++)
    {
        for (int j = 0; j <= WIDTH - 1; j++)
        {
            std::cout << maze[i][j];
        }
        std::cout << std::endl;
    }
    std::cout << "-------------------" << std::endl;
}


