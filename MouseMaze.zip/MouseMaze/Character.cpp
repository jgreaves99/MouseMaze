#include "Character.h"

Character::Character(char rep, char target, int x, int y, Maze *env)
{
    myChar = rep;
    myTarget = target;

    myX = x;
    myY = y;
    environment = env;

    cords recentLocal;
    recentLocal.arr[0] = myX;
    recentLocal.arr[1] = myY;

    foundList.push_back(recentLocal);
}

char Character::getRep()
{
    return myChar;
}

int Character::getX()
{
    return myX;
}

int Character::getY()
{
    return myY;
}

void Character::setLocation(int x, int y)
{
    myX = x;
    myY = y;
}

bool Character::foundTarget()
{
    if(environment->getNode(myX + 1, myY) == myTarget)
    {
        return true;
    }
    else if(environment->getNode(myX, myY + 1) == myTarget)
    {
        return true;
    }
    else if(environment->getNode(myX, myY - 1) == myTarget)
    {
        return true;
    }
    else if(environment->getNode(myX - 1, myY) == myTarget)
    {
        return true;
    }
    return false;
}

void Character::move()
{
    if(environment->getNode(myX + 1, myY) != '#' && !isDeadend(myX + 1, myY))
    {
        environment->setNode(this, myX + 1, myY);
    }
    else if(environment->getNode(myX, myY + 1) != '#' && !isDeadend(myX, myY + 1))
    {
        environment->setNode(this, myX, myY + 1);
    }
    else if(environment->getNode(myX, myY - 1) != '#' && !isDeadend(myX, myY - 1))
    {
        environment->setNode(this, myX, myY - 1);
    }
    else if(environment->getNode(myX - 1, myY) != '#' && !isDeadend(myX - 1, myY))
    {
        environment->setNode(this, myX - 1, myY);
    }

    cords recentLocal;
    recentLocal.arr[0] = myX;
    recentLocal.arr[1] = myY;

    foundList.push_back(recentLocal);
}

bool Character::wasFound(int x, int y)
{
    int foundCount = 0;
    cords currentCord;
    currentCord.arr[0] = x;
    currentCord.arr[1] = y;

    for(int i = 0; i <= foundList.size() - 1; i++)
    {
        if(currentCord.arr[0] == foundList.at(i).arr[0] && currentCord.arr[1] == foundList.at(i).arr[1])
            foundCount ++;
    }

    if(foundCount >= 1)
        return true;
    else
        return false;
}

bool Character::isDeadend(int x, int y)
{
    if((environment->getNode(myX + 1, myY) == '#' || wasFound(myX + 1, myY)) &&
       (environment->getNode(myX, myY + 1) == '#' || wasFound(myX, myY + 1)) &&
       (environment->getNode(myX, myY - 1) == '#' || wasFound(myX, myY - 1)) &&
       (environment->getNode(myX - 1, myY) == '#' || wasFound(myX - 1, myY)))
        return true;
    return false;
}