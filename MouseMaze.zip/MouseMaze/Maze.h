#ifndef MOUSEMAZE_MAZE_H
#define MOUSEMAZE_MAZE_H

#include <iostream>
#include <string>
#include "Character.h"
const int HEIGHT = 10;
const int WIDTH = 10;

class Character;
class Maze {
public:
    Maze();
    Maze(Character *character1, Character *character2);

    bool winnerFound();

    void update();

    void reset();
    void addCharacters(Character *character1, Character *character2);

    void setNode(Character *character, int x, int y);
    void clearNode(int x, int y);
    char getNode(int w, int h);

    void printMaze();

private:
    Character *mouse;
    Character *cat;

    char maze[HEIGHT][WIDTH];
};


#endif //MOUSEMAZE_MAZE_H
