#ifndef MOUSEMAZE_CHARACTER_H
#define MOUSEMAZE_CHARACTER_H

#include "Maze.h"
#include <vector>

class Maze;
class Character {
public:
    Character(char rep, char target, int x, int y, Maze *env);

    char getRep();
    int getX();
    int getY();
    void setLocation(int x, int y);

    bool foundTarget();
    void move();

private:
    char myChar, myTarget;
    int myX,myY;
    Maze *environment;

    struct cords{
        int arr[2];
    };

    std::vector<cords> foundList;

    bool wasFound(int x, int y);
    bool isDeadend(int x, int y);
};


#endif //MOUSEMAZE_CHARACTER_H
