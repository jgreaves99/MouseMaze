#include <iostream>
#include "Maze.h"

int main() {
    Maze *newMaze = new Maze();

    Character *mouse = new Character('M', 'F', 0, 1, newMaze);
    Character *cat = new Character('C', 'M', 0, 6, newMaze);

    newMaze->addCharacters(mouse, cat);

    while(!newMaze->winnerFound())
    {
        newMaze->update();
    }
    return 0;
}
